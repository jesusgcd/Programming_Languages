/*
  Autores:
    1)  William Gerardo Alfaro Quiros  – 2022437996
    2)  Jesus Gabriel Cordero Diaz     - 2020081049
*/


% Ejercicio 1 (10 puntos) Implemente un conjunto de reglas que maneje la jerarquía taxonómica de estas dos 
especies, como la que se muestra a continuación:

% Ejercicio 2 (2 puntos) Defina el predicado miembro(X,L), que se cumple si y solo si el elemento en X 
aparece en la lista L.

miembro(X, [X|_]).                      % Verifica si X está en la cabeza de la lista.
miembro(X, [_|T]) :- miembro(X, T).     % Recursivamente verifica en el resto de la lista.

% Ejercicio 3 Retorne el valor máximo de una lista.

maximo([X], X).                         % Caso base: lista de un elemento, X es el maximo.
maximo([H|T], X) :-                     % Caso recursivo: divide la lista en cabeza (H) y cola (T).
    maximo(T, MaxT),                    % Llamada recursiva para encontrar el maximo en la cola (MaxT).
    (H >= MaxT -> X = H ; X = MaxT).    % Compara H con MaxT para encontrar el maximo final.

% Ejercicio 4 Verifique si L es un subconjunto de K.

subconjunto([], _).                     % Caso base: un conjunto vacío es un subconjunto válido.
subconjunto([X|T], K) :-                % Verifica si X está en K y verifica recursivamente el resto de la lista.
    miembro(X, K),
    subconjunto(T, K).

/*
  Tests:

    Ejercicio 1:

% funtor para "Colibri thalassinus"

?- super(X,animalia). 
X = chordata ;
X = aves ;
X = apodiformes ;
X = trochilidae ;
X = colibri ;
X = eukaryota ;
false.


% funtor para "Ceiba pentandra"

?- super_(X,plantae).
X = magnoliophyta ;
X = magnoliopsida ;
X = dilleniidae ;
X = malvales ;
X = malvaceae ;
X = bombacoideae ;
X = ceiba ;
false.

    Ejercicio 2:
?- miembro(1, [1,2,3,4,5]).
true.

    Ejercicio 3:
?- maximo([1,2,3,4,5], X).
X = 5.
?- maximo([10,8,3,9,5], X).
X = 10.

    Ejercicio 4:
?- subconjunto([1,4,6], [1,2,3,4,5,6]).
true.
 
*/